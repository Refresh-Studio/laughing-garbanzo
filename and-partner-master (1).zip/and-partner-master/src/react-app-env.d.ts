// eslint-disable-next-line spaced-comment
/// <reference types="react-scripts" />

declare module 'react';
declare module 'react-dom';
declare module '@types/react';
